405410010 資工二 毛胤年

#在bag中有寫一個void trace()，它能印出bag中所有的物件。我把它用在印出combine與subtract後c_result的內容物。

#currentValue在finger指向NULL時，會回傳一個填滿\0的 object<ItemType> 。

