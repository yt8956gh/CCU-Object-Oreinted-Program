# 當進行+ - *時，如果矩陣規格（upper/lower 或者 rank）不一樣會回傳第一個operand。
