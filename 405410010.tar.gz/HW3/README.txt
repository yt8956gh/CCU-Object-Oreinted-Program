
1.
    The transaction class is saved with vector<transaction*>.
    Thus, the time of transaction is not limited by a constant number.

2. 
    The test driver called "main.cpp" uses random memony to test program,
    so the final result will be different every execution.